package com.technoapes.appsmovies;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

public class MovieDetails extends AppCompatActivity {



    ImageView imageMovie;
    TextView nameMovie;
    TextView dateMovie;
    TextView rateMovie;
    TextView overViewMovie;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_details);

        imageMovie = (ImageView) findViewById(R.id.imageMovie);
        nameMovie = (TextView) findViewById(R.id.nameMovie);
        dateMovie = (TextView) findViewById(R.id.dateMovie);
        rateMovie = (TextView) findViewById(R.id.rateMovie);
        overViewMovie = (TextView) findViewById(R.id.overViewMovie);



        String mTitle = getIntent().getStringExtra("title").toString();
        nameMovie.setText(mTitle);
        String mReleaseDate = getIntent().getStringExtra("release_date").toString();
        dateMovie.setText(mReleaseDate);
        String mOverView = getIntent().getStringExtra("overview").toString();
        overViewMovie.setText(mOverView);
        Double mRateMovie = getIntent().getDoubleExtra("vote_average",0.0);
        rateMovie.setText(mRateMovie.toString());

        String mPosterPath = getIntent().getStringExtra("poster_path").toString();

        Glide.with(this)
              .load("https://image.tmdb.org/t/p/w500"+mPosterPath)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .centerCrop()
                .into(imageMovie);


    }
}