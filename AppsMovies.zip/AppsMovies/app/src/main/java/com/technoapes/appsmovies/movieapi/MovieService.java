package com.technoapes.appsmovies.movieapi;

import com.technoapes.appsmovies.models.MovieRespuesta;

import retrofit2.Call;
import retrofit2.http.GET;

public interface MovieService {

    @GET("movie/popular?api_key=2f111a9ec6beacc93e6e1119cd9cae22") //movies/?api_key=478bfc045aea556e4ebefe909cb5a5607077e746&format=json
    Call<MovieRespuesta> obtenerListaMovies();
}
