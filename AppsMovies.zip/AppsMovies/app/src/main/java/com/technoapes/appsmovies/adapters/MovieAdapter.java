package com.technoapes.appsmovies.adapters;

import android.content.Context;
import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.technoapes.appsmovies.MainActivity;
import com.technoapes.appsmovies.MovieDetails;
import com.technoapes.appsmovies.R;
import com.technoapes.appsmovies.models.Movies;

import java.util.ArrayList;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.ViewHolder> {

    private ArrayList<Movies> dataset;
    private Context context;


    public MovieAdapter(Context context){
        this.context = context;
        dataset = new ArrayList<>();
    }


    @NonNull
    @Override
    public MovieAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_movie,parent,false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MovieAdapter.ViewHolder holder, int position) {
        Movies m = dataset.get(position);
        holder.txt_name.setText(m.getName());
        holder.txt_rate.setText(m.getVote_average().toString());//"https://image.tmdb.org/t/p/w500"

        holder.cv.setOnClickListener(view -> {
            Intent intent = new Intent(context,MovieDetails.class);

            intent.putExtra("title",m.getName());
            intent.putExtra("overview",m.getOverview());
            intent.putExtra("release_date",m.getRelease_date());
            intent.putExtra("poster_path",m.getImageUrl());
            intent.putExtra("vote_average",m.getVote_average());
            context.startActivity(intent);
        });

        Glide.with(context)
                .load( "https://image.tmdb.org/t/p/w500"+m.getImageUrl())
                .centerCrop()
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(holder.image_View);
    }

    @Override
    public int getItemCount() {
        return dataset.size();
    }


    public void adicionarListaPeliculas(ArrayList<Movies> listaPeliculas) {
        dataset.addAll(listaPeliculas);
        notifyDataSetChanged();

    }


    public  class ViewHolder extends RecyclerView.ViewHolder { //implements View.OnClickListener{

        private ImageView image_View;
        private TextView txt_name;
        private TextView txt_rate;
        private CardView cv;


        public ViewHolder(View itemView){
            super(itemView);
            image_View = (ImageView) itemView.findViewById(R.id.imageView);
            txt_name = (TextView) itemView.findViewById(R.id.txtname);
            txt_rate = (TextView) itemView.findViewById(R.id.txtrate);
            cv = (CardView) itemView.findViewById(R.id.cv);

        }

    }
}
