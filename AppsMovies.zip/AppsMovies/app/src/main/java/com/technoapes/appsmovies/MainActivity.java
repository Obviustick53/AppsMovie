package com.technoapes.appsmovies;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Movie;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.technoapes.appsmovies.adapters.MovieAdapter;
import com.technoapes.appsmovies.models.MovieRespuesta;
import com.technoapes.appsmovies.models.Movies;
import com.technoapes.appsmovies.movieapi.MovieService;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private static final String TAG= "ListMovies";

    private Retrofit retrofit;

    private RecyclerView recyclerView;
    private MovieAdapter movieAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);

        movieAdapter = new MovieAdapter(this);
        recyclerView.setAdapter(movieAdapter);
        recyclerView.setHasFixedSize(true);
        GridLayoutManager layoutManager = new GridLayoutManager(this, 3);
        recyclerView.setLayoutManager(layoutManager);

        retrofit = new Retrofit.Builder()
                .baseUrl("https://api.themoviedb.org/3/") //https://comicvine.gamespot.com/api/  -----  https://api.themoviedb.org/3/
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        obtenerDatos();
    }


    private void obtenerDatos(){
        MovieService service = retrofit.create(MovieService.class);
        Call<MovieRespuesta> movieRespuestaCall = service.obtenerListaMovies();

        movieRespuestaCall.enqueue(new Callback<MovieRespuesta>() {
            @Override
            public void onResponse(Call<MovieRespuesta> call, Response<MovieRespuesta> response) {
                if(response.isSuccessful()){
                    MovieRespuesta movieRespuesta = response.body();
                    ArrayList<Movies> listaPeliculas = movieRespuesta.getResults();

                    movieAdapter.adicionarListaPeliculas(listaPeliculas);


                } else{
                    Log.e(TAG,"onResponse: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<MovieRespuesta> call, Throwable t) {
                Log.e(TAG,"onFailure: " + t.getMessage());
            }
        });
    }
}