package com.technoapes.appsmovies.models;

import java.util.ArrayList;

public class MovieRespuesta {

    private ArrayList<Movies> results;

    public ArrayList<Movies> getResults() {
        return results;
    }

    public void setResults(ArrayList<Movies> results) {
        this.results = results;
    }
}
