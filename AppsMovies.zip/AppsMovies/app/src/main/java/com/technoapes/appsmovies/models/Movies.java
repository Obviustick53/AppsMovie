package com.technoapes.appsmovies.models;

public class Movies {

    private String title;  //name --- title
    private int id;
    private String release_date;
    private String poster_path;//original_url --- poster_path
    private Double vote_average;
    private String overview;


    public String getName() {
        return title;
    }

    public void setName(String name) {
        this.title = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRelease_date() {
        return release_date;
    }

    public void setRelease_date(String release_date) {
        this.release_date = release_date;
    }

    public String getImageUrl() {
        return poster_path;
    }

    public void setImageUrl(String imageUrl) {
        this.poster_path = imageUrl;
    }

    public Double getVote_average() {
        return vote_average;
    }

    public void setVote_average(Double vote_average) {
        this.vote_average = vote_average;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }
}
